import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class ProfilePage extends StatefulWidget {
  final bool standalone;
  const ProfilePage({super.key, this.standalone = true});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _tabIndex = 0;
  final _tabs = ['All Projects', 'Case Studies', 'Drafts'];

  final _portfolioItems = [
    {
      'title': 'Veridia Ecosystem',
      'desc': 'A multi-platform design system for a sustainable energy monitoring hub, serving over 10k users.',
      'tag': 'FEATURED CASE STUDY',
      'likes': null,
      'date': 'Mar 2024',
      'icon': Icons.eco_outlined,
      'color': const Color(0xFF0D3D30),
    },
    {
      'title': 'Nexus Dash',
      'desc': 'Real-time collaboration analytics for remote-first creative agencies.',
      'tag': null,
      'likes': 412,
      'date': 'Jan 2024',
      'icon': Icons.analytics_outlined,
      'color': const Color(0xFF0D2535),
    },
    {
      'title': 'Palette Gen Pro',
      'desc': 'AI-driven color theory assistant for digital illustrators and UI designers.',
      'tag': null,
      'likes': null,
      'date': 'Nov 2023',
      'icon': Icons.color_lens_outlined,
      'color': const Color(0xFF2D1535),
    },
  ];

  final _skills = ['UI Architecture', 'React Flow', 'Design Ops', 'Micro-interactions', 'TypeScript', 'Accessibility'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(context),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    _buildPortfolioHeader(),
                    const SizedBox(height: 16),
                    _buildTabBar(),
                    const SizedBox(height: 16),
                    _buildPortfolioGrid(),
                    const SizedBox(height: 20),
                    _buildRecentActivity(),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: AppColors.card,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(color: AppColors.teal, borderRadius: BorderRadius.circular(6)),
                    child: const Icon(Icons.hub, color: Colors.black, size: 16),
                  ),
                  const SizedBox(width: 8),
                  const Text('Synchronise', style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w800)),
                ],
              ),
              const Icon(Icons.settings_outlined, color: AppColors.textMuted),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Stack(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [AppColors.teal, Color(0xFF6B7ADE)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Icon(Icons.person, color: Colors.white, size: 40),
                  ),
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        color: AppColors.activeGreen,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.card, width: 2),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('Alex Sterling', style: TextStyle(color: AppColors.textPrimary, fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                    SizedBox(height: 2),
                    Text('SENIOR UI/UX ARCHITECT', style: TextStyle(color: AppColors.teal, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
                    SizedBox(height: 6),
                    Text(
                      'Passionate about crafting human-centered digital experiences. Based in San Francisco.',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 12, height: 1.4),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.share, size: 14),
                  label: const Text('SHARE PROFILE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    elevation: 0,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.edit, size: 14, color: AppColors.textSecondary),
                  label: const Text('EDIT DETAILS', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5, color: AppColors.textSecondary)),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: const [
                  Icon(Icons.auto_awesome, color: AppColors.teal, size: 14),
                  SizedBox(width: 6),
                  Text('Skillset', style: TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _skills.map((s) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.tealBg,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.teal.withOpacity(0.3)),
                  ),
                  child: Text(s, style: const TextStyle(color: AppColors.teal, fontSize: 12, fontWeight: FontWeight.w500)),
                )).toList(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPortfolioHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text('Portfolio', style: TextStyle(color: AppColors.textPrimary, fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
        SizedBox(height: 4),
        Text('A curated selection of recent creative collaborations.', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
      ],
    );
  }

  Widget _buildTabBar() {
    return Row(
      children: List.generate(_tabs.length, (i) {
        final selected = i == _tabIndex;
        return Padding(
          padding: const EdgeInsets.only(right: 20),
          child: GestureDetector(
            onTap: () => setState(() => _tabIndex = i),
            child: Column(
              children: [
                Text(
                  _tabs[i],
                  style: TextStyle(
                    color: selected ? AppColors.textPrimary : AppColors.textMuted,
                    fontSize: 13,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 4),
                if (selected)
                  Container(
                    height: 2,
                    width: _tabs[i].length * 7.0,
                    color: AppColors.teal,
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget _buildPortfolioGrid() {
    return Column(
      children: [
        ..._portfolioItems.map((item) => _buildPortfolioCard(item)).toList(),
        _buildAddProjectCard(),
      ],
    );
  }

  Widget _buildPortfolioCard(Map<String, dynamic> item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 120,
            decoration: BoxDecoration(
              color: item['color'] as Color,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Stack(
              children: [
                Center(child: Icon(item['icon'] as IconData, size: 48, color: AppColors.teal.withOpacity(0.25))),
                if (item['tag'] != null)
                  Positioned(
                    top: 12,
                    left: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.tealBg,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: AppColors.teal.withOpacity(0.4)),
                      ),
                      child: Text(item['tag'] as String, style: const TextStyle(color: AppColors.teal, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item['title'] as String, style: const TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(item['desc'] as String, style: const TextStyle(color: AppColors.textMuted, fontSize: 12, height: 1.5)),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(item['date'] as String, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                    Row(
                      children: [
                        if (item['likes'] != null) ...[
                          const Icon(Icons.favorite_outline, color: AppColors.textMuted, size: 14),
                          const SizedBox(width: 4),
                          Text('${item['likes']}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                          const SizedBox(width: 12),
                        ],
                        const Icon(Icons.arrow_forward, color: AppColors.teal, size: 16),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddProjectCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      height: 120,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border, style: BorderStyle.solid, width: 1.5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(Icons.add, color: AppColors.textMuted, size: 28),
          SizedBox(height: 8),
          Text('Add Project', style: TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
          SizedBox(height: 4),
          Text('Share your latest masterpiece.', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildRecentActivity() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Recent Activity', style: TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w700)),
              TextButton(
                onPressed: () {},
                child: const Text('View All', style: TextStyle(color: AppColors.teal, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildActivityItem(Icons.comment_outlined, 'Yesterday', 'Commented on ', '"Fluid Dynamics Branding"', ' by Jordan Reed.'),
          const Divider(color: AppColors.border, height: 20),
          _buildActivityItem(Icons.group_add_outlined, 'Oct 24, 2023', 'Joined the ', 'Web Accessibility Guild', ' as a Founding Member.'),
        ],
      ),
    );
  }

  Widget _buildActivityItem(IconData icon, String date, String pre, String highlight, String post) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(8)),
          child: Icon(icon, color: AppColors.textMuted, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(date, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
              const SizedBox(height: 2),
              RichText(
                text: TextSpan(
                  style: const TextStyle(fontSize: 13, height: 1.4),
                  children: [
                    TextSpan(text: pre, style: const TextStyle(color: AppColors.textSecondary)),
                    TextSpan(text: highlight, style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w600)),
                    TextSpan(text: post, style: const TextStyle(color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
